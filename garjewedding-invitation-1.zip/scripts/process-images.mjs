import sharp from "sharp";
import fs from "node:fs";
import path from "node:path";

const src = "public/images";
const out = "src/assets";
fs.mkdirSync(out, { recursive: true });

function hexToRgb(h) {
  return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
}

async function knockOut(file, bgHex, lo, hi, width, quality = 88) {
  const bg = hexToRgb(bgHex);
  const img = sharp(path.join(src, file)).resize({ width, withoutEnlargement: true });
  const { data, info } = await img.ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const n = info.width * info.height;
  for (let i = 0; i < n; i++) {
    const o = i * 4;
    const d = Math.sqrt(
      (data[o] - bg[0]) ** 2 + (data[o + 1] - bg[1]) ** 2 + (data[o + 2] - bg[2]) ** 2
    );
    let a = (d - lo) / (hi - lo);
    a = a < 0 ? 0 : a > 1 ? 1 : a;
    // slight gamma to keep edges crisp
    a = Math.pow(a, 0.75);
    data[o + 3] = Math.round(a * 255);
  }
  const dest = path.join(out, file.replace(/\.(png|jpg|jpeg)$/i, ".webp"));
  await sharp(data, { raw: { width: info.width, height: info.height, channels: 4 } })
    .webp({ quality })
    .toFile(dest);
  console.log(dest, (fs.statSync(dest).size / 1024).toFixed(0) + "kb", info.width + "x" + info.height);
}

async function plain(file, width, quality = 74) {
  const dest = path.join(out, file.replace(/\.(png|jpg|jpeg)$/i, ".jpg"));
  await sharp(path.join(src, file))
    .resize({ width, withoutEnlargement: true })
    .jpeg({ quality, mozjpeg: true })
    .toFile(dest);
  console.log(dest, (fs.statSync(dest).size / 1024).toFixed(0) + "kb");
}

const CREAM = "#F7EFDF";
const WINE = "#4A0B14";

await knockOut("ganesh.png", WINE, 26, 86, 620, 76);
await knockOut("rose-corner.png", CREAM, 18, 66, 900);
await knockOut("rose-spray.png", CREAM, 18, 66, 950);
await knockOut("haldi.png", CREAM, 18, 66, 820);
await knockOut("rings.png", CREAM, 18, 66, 800);
await knockOut("mandala.png", CREAM, 16, 58, 820, 68);
await plain("roses-hero.jpg", 1500, 76);
await plain("parchment.jpg", 1100, 70);
