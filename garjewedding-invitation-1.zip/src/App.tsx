import { useCallback, useEffect, useState } from "react";
import { Backdrop } from "@/components/Backdrop";
import { Opening } from "@/components/Opening";
import { TopNav } from "@/components/TopNav";
import { InvitationHero } from "@/components/InvitationHero";
import { Couple } from "@/components/Couple";
import { Muhurat } from "@/components/Muhurat";
import { Haldi, Travel } from "@/components/Events";
import { Family, Footer } from "@/components/Closing";
import { RoseBand } from "@/components/ui";
import { cn } from "@/utils/cn";

function BackToTop({ show }: { show: boolean }) {
  return (
    <button
      type="button"
      aria-label="वर जा"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className={cn(
        "btn-royal fixed right-4 bottom-5 z-40 grid h-12 w-12 place-items-center rounded-full border border-gold-300/70 bg-[linear-gradient(140deg,#6f1020,#9b1b30_55%,#3a0812)] text-gold-100 shadow-[0_16px_34px_-16px_rgba(37,5,12,0.9)] transition-all duration-500 sm:right-7 sm:bottom-7 sm:h-14 sm:w-14",
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"
      )}
    >
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 19V6M6 12l6-6 6 6" />
      </svg>
    </button>
  );
}

export default function App() {
  const [phase, setPhase] = useState<"intro" | "leaving" | "done">("intro");
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    document.body.style.overflow = phase === "done" ? "" : "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [phase]);

  useEffect(() => {
    if (phase !== "done") return;
    const onScroll = () => setShowTop(window.scrollY > 700);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [phase]);

  const enter = useCallback(() => {
    setPhase("leaving");
    window.scrollTo({ top: 0, behavior: "auto" });
    window.setTimeout(() => setPhase("done"), 900);
  }, []);

  return (
    <div className="relative min-h-screen">
      <Backdrop />

      {phase !== "intro" && (
        <div className="unfold relative">
          <InvitationHero />
          <Couple />
          <RoseBand mark="॥" />
          <Muhurat />
          <Haldi />
          <Travel />
          <RoseBand mark="श्री" />
          <Family />
          <Footer />
        </div>
      )}

      <TopNav active={phase === "done"} />
      <BackToTop show={phase === "done" && showTop} />
      {phase !== "done" && <Opening onEnter={enter} />}
    </div>
  );
}
