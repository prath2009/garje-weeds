import ganesh from "@/assets/ganesh.webp";
import roseCorner from "@/assets/rose-corner.webp";
import roseSpray from "@/assets/rose-spray.webp";
import haldi from "@/assets/haldi.webp";
import rings from "@/assets/rings.webp";
import mandala from "@/assets/mandala.webp";
import rosesHero from "@/assets/roses-hero.jpg";
import parchment from "@/assets/parchment.jpg";

export const IMG = {
  ganesh,
  roseCorner,
  roseSpray,
  haldi,
  rings,
  mandala,
  rosesHero,
  parchment,
};

/** शुभविवाह मुहूर्त — गुरुवार, दिनांक १० डिसेंबर २०२६, दुपारी १२ वाजून १९ मिनिटांनी */
export const MUHURTA = new Date("2026-12-10T12:19:00+05:30").getTime();

export const CONTACT = { name: "प्रभाकर गर्जे", phone: "9511641991" };
