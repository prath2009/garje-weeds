import {
  useEffect,
  useId,
  useMemo,
  useRef,
  type CSSProperties,
  type ReactNode,
} from "react";
import { cn } from "@/utils/cn";
import { IMG } from "@/lib/assets";

const rand = (a: number, b: number) => a + Math.random() * (b - a);

/* ------------------------------------------------------------------ */
/* Scroll reveal                                                       */
/* ------------------------------------------------------------------ */
export function Reveal({
  children,
  dir = "up",
  delay = 0,
  className,
  id,
  style,
}: {
  children: ReactNode;
  dir?: "up" | "down" | "left" | "right" | "zoom";
  delay?: number;
  className?: string;
  id?: string;
  style?: CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      el.classList.add("is-in");
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            el.classList.add("is-in");
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -6% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      id={id}
      ref={ref}
      data-reveal={dir}
      style={{ transitionDelay: `${delay}ms`, ...style }}
      className={className}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Pointer tilt (desktop only)                                         */
/* ------------------------------------------------------------------ */
export function useTilt<T extends HTMLElement>(max = 4) {
  const ref = useRef<T>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof window.matchMedia === "function" && window.matchMedia("(hover: none)").matches)
      return;

    let raf = 0;
    const onMove = (e: PointerEvent) => {
      if (raf) return;
      raf = window.requestAnimationFrame(() => {
        raf = 0;
        const r = el.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        el.style.transform = `perspective(1500px) rotateX(${(-py * max).toFixed(2)}deg) rotateY(${(
          px * max
        ).toFixed(2)}deg)`;
      });
    };
    const onLeave = () => {
      el.style.transform = "perspective(1500px) rotateX(0deg) rotateY(0deg)";
    };

    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerleave", onLeave);
    return () => {
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerleave", onLeave);
      if (raf) window.cancelAnimationFrame(raf);
    };
  }, [max]);

  return ref;
}

/* ------------------------------------------------------------------ */
/* Falling rose petals                                                 */
/* ------------------------------------------------------------------ */
export function Petals({
  count = 18,
  className,
  minSize = 9,
  maxSize = 22,
  minDur = 11,
  maxDur = 21,
}: {
  count?: number;
  className?: string;
  minSize?: number;
  maxSize?: number;
  minDur?: number;
  maxDur?: number;
}) {
  const petals = useMemo(
    () =>
      Array.from({ length: count }, () => {
        const size = rand(minSize, maxSize);
        return {
          left: rand(-2, 100),
          size,
          dur: rand(minDur, maxDur),
          delay: -rand(0, maxDur),
          tumble: rand(3.4, 7.6),
          tumbleDelay: -rand(0, 7),
          drift: rand(-16, 16),
          opacity: rand(0.5, 1),
          blur: size > maxSize * 0.82 ? rand(0.5, 2.1) : 0,
        };
      }),
    [count, minSize, maxSize, minDur, maxDur]
  );

  return (
    <div aria-hidden className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)}>
      {petals.map((p, i) => (
        <span
          key={i}
          className="absolute top-0 will-change-transform"
          style={
            {
              left: `${p.left}%`,
              animation: `petal-fall ${p.dur}s linear ${p.delay}s infinite`,
              "--drift": `${p.drift}vw`,
            } as CSSProperties
          }
        >
          <span
            className="petal absolute top-0 left-0"
            style={{
              width: p.size,
              height: p.size * 0.86,
              opacity: p.opacity,
              filter: p.blur ? `blur(${p.blur}px)` : undefined,
              animation: `petal-tumble ${p.tumble}s ease-in-out ${p.tumbleDelay}s infinite`,
            }}
          />
        </span>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Golden dust motes                                                   */
/* ------------------------------------------------------------------ */
export function GoldDust({ count = 26, className }: { count?: number; className?: string }) {
  const motes = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        left: rand(0, 100),
        top: rand(10, 100),
        size: rand(1.6, 4.2),
        dur: rand(6, 14),
        delay: -rand(0, 14),
        dx: rand(-40, 40),
        opacity: rand(0.35, 0.95),
      })),
    [count]
  );
  return (
    <div aria-hidden className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)}>
      {motes.map((m, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-gold-200"
          style={
            {
              left: `${m.left}%`,
              top: `${m.top}%`,
              width: m.size,
              height: m.size,
              opacity: m.opacity,
              boxShadow: "0 0 8px 2px rgba(226,198,120,0.55)",
              animation: `dust ${m.dur}s ease-in-out ${m.delay}s infinite`,
              "--dx": `${m.dx}px`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Corner filigree                                                     */
/* ------------------------------------------------------------------ */
export function CornerFiligree({
  className,
  flipX = false,
  flipY = false,
}: {
  className?: string;
  flipX?: boolean;
  flipY?: boolean;
}) {
  const uid = useId().replace(/:/g, "");
  return (
    <svg
      viewBox="0 0 120 120"
      aria-hidden
      className={cn("h-20 w-20", className)}
      style={{ transform: `scale(${flipX ? -1 : 1}, ${flipY ? -1 : 1})` }}
    >
      <defs>
        <linearGradient id={`cg${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f6e3a8" />
          <stop offset="45%" stopColor="#d4af37" />
          <stop offset="100%" stopColor="#8a6617" />
        </linearGradient>
      </defs>
      <g fill="none" stroke={`url(#cg${uid})`} strokeWidth="1.5" strokeLinecap="round">
        <path d="M5 5h46" />
        <path d="M5 5v46" />
        <path d="M13 13h30" opacity="0.65" />
        <path d="M13 13v30" opacity="0.65" />
        <path d="M5 66C6 40 20 20 46 12" opacity="0.5" />
        <path
          d="M22 100C22 63 42 34 80 23c-17 14-27 31-28 52 0-19 8-33 23-40-12 12-16 26-14 42z"
          fill={`url(#cg${uid})`}
          fillOpacity="0.32"
          strokeWidth="1"
        />
        <path d="M56 8c5 8 5 15 0 22-5-7-5-14 0-22z" fill={`url(#cg${uid})`} fillOpacity="0.45" />
        <path d="M8 56c8-5 15-5 22 0-7 5-14 5-22 0z" fill={`url(#cg${uid})`} fillOpacity="0.45" />
      </g>
      <g fill={`url(#cg${uid})`}>
        <circle cx="88" cy="16" r="3" />
        <circle cx="16" cy="88" r="3" />
        <circle cx="66" cy="34" r="1.8" opacity="0.8" />
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Divider with rose rosette                                           */
/* ------------------------------------------------------------------ */
export function Divider({
  className,
  tone = "gold",
  width = 620,
}: {
  className?: string;
  tone?: "gold" | "wine";
  width?: number;
}) {
  const uid = useId().replace(/:/g, "");
  const stroke = tone === "gold" ? `url(#dg${uid})` : `url(#dw${uid})`;
  return (
    <svg
      viewBox="0 0 620 46"
      width={width}
      aria-hidden
      className={cn("mx-auto block max-w-full", className)}
      style={{ height: "auto" }}
    >
      <defs>
        <linearGradient id={`dg${uid}`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#d4af37" stopOpacity="0" />
          <stop offset="30%" stopColor="#d4af37" />
          <stop offset="55%" stopColor="#f6e3a8" />
          <stop offset="100%" stopColor="#d4af37" stopOpacity="0" />
        </linearGradient>
        <linearGradient id={`dw${uid}`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#9b1b30" stopOpacity="0" />
          <stop offset="40%" stopColor="#9b1b30" />
          <stop offset="60%" stopColor="#b01e33" />
          <stop offset="100%" stopColor="#9b1b30" stopOpacity="0" />
        </linearGradient>
      </defs>
      <g fill="none" stroke={stroke} strokeWidth="1.4">
        <path d="M8 23h236" />
        <path d="M376 23h236" />
        <path d="M120 15c26 0 44 4 62 8M120 31c26 0 44-4 62-8" opacity="0.55" />
        <path d="M500 15c-26 0-44 4-62 8M500 31c-26 0-44-4-62-8" opacity="0.55" />
      </g>
      <g fill={stroke}>
        <path d="M258 23l8-6 8 6-8 6z" />
        <path d="M338 23l8-6 8 6-8 6z" />
      </g>
      <g transform="translate(310 23)">
        <circle r="17" fill="none" stroke={stroke} strokeWidth="1.2" opacity="0.75" />
        <circle r="21.5" fill="none" stroke={stroke} strokeWidth="0.7" strokeDasharray="2 4" />
        {Array.from({ length: 10 }).map((_, i) => (
          <path
            key={i}
            transform={`rotate(${i * 36})`}
            d="M0 -3.5C5 -12 12 -13 14.5 -5C11 1.5 4 2.5 0 -3.5Z"
            fill={stroke}
            opacity="0.85"
          />
        ))}
        <circle r="3.4" fill={stroke} />
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Rose corner bouquet                                                 */
/* ------------------------------------------------------------------ */
export function RoseCorner({
  className,
  flipX = false,
  flipY = false,
  float = true,
}: {
  className?: string;
  flipX?: boolean;
  flipY?: boolean;
  float?: boolean;
}) {
  return (
    <img
      src={IMG.roseCorner}
      alt=""
      aria-hidden
      loading="lazy"
      className={cn(
        "pointer-events-none absolute select-none glow-rose",
        float && "anim-float-sm",
        flipX && "-scale-x-100",
        flipY && "-scale-y-100",
        className
      )}
    />
  );
}

/* ------------------------------------------------------------------ */
/* Ornate framed panel                                                 */
/* ------------------------------------------------------------------ */
export function OrnateFrame({
  children,
  className,
  innerClassName,
  roses = true,
  filigree = true,
  tone = "gold",
}: {
  children: ReactNode;
  className?: string;
  innerClassName?: string;
  roses?: boolean;
  filigree?: boolean;
  tone?: "gold" | "wine";
}) {
  const line = tone === "gold" ? "border-gold-400/60" : "border-gold-300/40";
  return (
    <div className={cn("relative", className)}>
      <div
        aria-hidden
        className={cn("pointer-events-none absolute inset-0 rounded-[26px] border", line)}
      />
      <div
        aria-hidden
        className={cn(
          "pointer-events-none absolute inset-[9px] rounded-[19px] border border-dashed",
          tone === "gold" ? "border-gold-500/40" : "border-gold-200/25"
        )}
      />
      {filigree && (
        <>
          <CornerFiligree className="absolute -top-2 -left-2 h-16 w-16 opacity-90 sm:h-20 sm:w-20" />
          <CornerFiligree className="absolute -top-2 -right-2 h-16 w-16 opacity-90 sm:h-20 sm:w-20" flipX />
          <CornerFiligree className="absolute -bottom-2 -left-2 h-16 w-16 opacity-90 sm:h-20 sm:w-20" flipY />
          <CornerFiligree
            className="absolute -right-2 -bottom-2 h-16 w-16 opacity-90 sm:h-20 sm:w-20"
            flipX
            flipY
          />
        </>
      )}
      {roses && (
        <>
          <RoseCorner className="-top-14 -left-16 w-40 rotate-[-8deg] sm:-left-20 sm:w-56 md:w-64" />
          <RoseCorner
            className="-right-16 -bottom-14 w-40 rotate-[6deg] sm:-right-20 sm:w-56 md:w-64"
            flipX
            flipY
          />
        </>
      )}
      <div className={cn("relative", innerClassName)}>{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Rose garland band — section separator                               */
/* ------------------------------------------------------------------ */
export function RoseBand({ mark = "॥" }: { mark?: string }) {
  return (
    <div aria-hidden className="relative flex items-center justify-center overflow-hidden px-4 py-7 sm:py-9">
      <span className="shimmer-rule absolute inset-x-6 top-1/2 h-px" />
      <img
        src={IMG.roseSpray}
        alt=""
        className="anim-float-sm relative w-28 -rotate-6 opacity-95 sm:w-44"
      />
      <span className="relative mx-3 grid h-11 w-11 shrink-0 place-items-center rounded-full border border-gold-400/70 bg-[radial-gradient(circle_at_35%_30%,#fffaf1,#f0dca2_60%,#e2cd9b)] font-display text-lg text-wine-700 shadow-[0_10px_24px_-12px_rgba(58,8,18,0.8)] sm:mx-5 sm:h-14 sm:w-14 sm:text-xl">
        {mark}
      </span>
      <img
        src={IMG.roseSpray}
        alt=""
        className="anim-float-sm relative w-28 -scale-x-100 rotate-6 opacity-95 sm:w-44"
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Small caps eyebrow label                                            */
/* ------------------------------------------------------------------ */
export function Eyebrow({
  children,
  className,
  tone = "wine",
}: {
  children: ReactNode;
  className?: string;
  tone?: "wine" | "gold";
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-center gap-3 text-[11px] tracking-[0.42em] uppercase sm:text-xs",
        tone === "wine" ? "text-wine-700/75" : "text-gold-200/80",
        className
      )}
    >
      <span className={cn("h-px w-8 sm:w-14", tone === "wine" ? "bg-gold-500/50" : "bg-gold-300/40")} />
      <span className="font-latin">{children}</span>
      <span className={cn("h-px w-8 sm:w-14", tone === "wine" ? "bg-gold-500/50" : "bg-gold-300/40")} />
    </div>
  );
}
