import { IMG } from "@/lib/assets";
import { Divider, Eyebrow, OrnateFrame, Reveal, RoseCorner } from "@/components/ui";
import { cn } from "@/utils/cn";

type PersonProps = {
  role: string;
  roleEn: string;
  name: string;
  monogram: string;
  lines: string[];
  address: string;
  side: "left" | "right";
  tone: "groom" | "bride";
  delay?: number;
};

function Person({ role, roleEn, name, monogram, lines, address, side, tone, delay = 0 }: PersonProps) {
  return (
    <Reveal dir={side === "left" ? "left" : "right"} delay={delay} className="h-full">
      <div className="card-lift panel-gold ring-gold group relative h-full overflow-hidden rounded-[28px] px-5 py-10 sm:px-8 sm:py-12">
        {/* inner damask sheen */}
        <div className="damask pointer-events-none absolute inset-0 opacity-40" />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(80%_50%_at_50%_0%,rgba(212,175,55,0.18),transparent_70%)]" />

        <RoseCorner
          className={cn(
            "w-28 opacity-90 transition-transform duration-700 group-hover:scale-105 sm:w-36",
            side === "left" ? "-top-10 -left-12" : "-top-10 -right-12",
            side === "right" && "scale-x-[-1]"
          )}
          float={false}
        />

        <div className="relative flex flex-col items-center text-center">
          {/* arched portrait frame */}
          <div className="relative mb-6">
            <div
              className={cn(
                "relative grid h-44 w-36 place-items-center rounded-t-full rounded-b-3xl border-2 border-gold-400/70 shadow-[0_22px_44px_-24px_rgba(58,8,18,0.85),inset_0_0_30px_rgba(0,0,0,0.45)] transition-transform duration-700 group-hover:scale-[1.03] sm:h-52 sm:w-44",
                tone === "groom"
                  ? "bg-[radial-gradient(120%_90%_at_50%_15%,#7d1425,#3a0812_62%,#25050c)]"
                  : "bg-[radial-gradient(120%_90%_at_50%_15%,#b01e33,#68101f_58%,#310710)]"
              )}
            >
              <div className="damask-dark absolute inset-[7px] rounded-t-full rounded-b-[18px] border border-dashed border-gold-300/40" />
              <div className="anim-halo absolute -inset-5 rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.3),transparent_66%)] blur-md" />
              <span className="foil relative font-display text-7xl leading-none sm:text-8xl">
                {monogram}
              </span>
              <span className="absolute bottom-4 font-latin text-[10px] tracking-[0.34em] text-gold-200/70 uppercase">
                {roleEn}
              </span>
            </div>
            <img
              src={IMG.roseSpray}
              alt=""
              aria-hidden
              className={cn(
                "anim-float-sm pointer-events-none absolute -bottom-9 w-40 sm:w-48",
                side === "left" ? "-right-14 rotate-6" : "-left-14 -scale-x-100 rotate-6"
              )}
            />
          </div>

          <p className="foil-deep font-display text-xl tracking-[0.14em] sm:text-2xl">{role}</p>
          <h3 className="foil-wine mt-1 font-display text-2xl leading-tight sm:text-4xl">{name}</h3>

          <div className="my-4 w-full max-w-[16rem]">
            <Divider tone="wine" width={260} />
          </div>

          <div className="space-y-1.5 text-[15px] leading-relaxed text-wine-800/85 sm:text-base">
            {lines.map((l) => (
              <p key={l}>{l}</p>
            ))}
          </div>

          <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-gold-400/50 bg-[linear-gradient(120deg,rgba(255,250,241,0.9),rgba(240,220,162,0.4))] px-4 py-2">
            <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-gold-600" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11z" />
              <circle cx="12" cy="10" r="2.4" />
            </svg>
            <span className="text-sm font-medium text-wine-800 sm:text-[15px]">{address}</span>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

export function Couple() {
  return (
    <section id="varavadhu" className="relative px-4 py-16 sm:px-6 sm:py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal className="text-center">
          <Eyebrow tone="wine">The Bride &amp; The Groom</Eyebrow>
          <h2 className="foil-deep mt-3 font-display text-4xl sm:text-6xl">वर आणि वधू</h2>
          <p className="mx-auto mt-3 max-w-xl text-[15px] leading-relaxed text-wine-800/70 sm:text-base">
            दोन परिवारांचे मनमिलाप, दोन जीवांचा अतूट बंध — सोहळ्याच्या शुभप्रसंगी आपल्या
            आशीर्वादाची अपेक्षा.
          </p>
        </Reveal>

        <div className="mt-12 grid items-stretch gap-10 lg:grid-cols-[1fr_auto_1fr] lg:gap-6">
          <Person
            side="left"
            tone="groom"
            role="वर"
            roleEn="Groom"
            monogram="प"
            name="चि. पवन"
            lines={[
              "श्री. जयसिंगराव गर्जे पाटील यांचे नातू व",
              "सौ. अलका व प्रभाकरराव जयसिंगराव गर्जे यांचे ज्येष्ठ चिरंजीव",
            ]}
            address="रा. शिंदेनगर, कॅनॉल रोड, बीड."
          />

          {/* centre ornament — golden rings */}
          <Reveal dir="zoom" delay={160} className="flex justify-center lg:items-center">
            <div className="relative flex flex-col items-center">
              <span className="hidden h-16 w-px bg-[linear-gradient(180deg,transparent,#bd9528)] lg:block" />
              <div className="relative grid h-40 w-40 place-items-center sm:h-48 sm:w-48">
                <div className="anim-halo absolute inset-0 rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.42),transparent_64%)] blur-lg" />
                <div className="anim-spin-slow absolute inset-0 rounded-full border border-dashed border-gold-500/60" />
                <div className="absolute inset-3 rounded-full border border-gold-400/70 bg-[radial-gradient(circle_at_40%_30%,#fffaf1,#f0dca2_58%,#e0cda0)] shadow-[0_20px_44px_-24px_rgba(58,8,18,0.75)]" />
                <img
                  src={IMG.rings}
                  alt="शुभविवाह वलय"
                  className="anim-float relative z-10 h-[86%] w-[86%] object-contain"
                />
              </div>
              <span className="mt-4 font-latin text-[10px] tracking-[0.4em] text-gold-600 uppercase">
                Two Hearts · One Soul
              </span>
              <span className="hidden h-16 w-px bg-[linear-gradient(0deg,transparent,#bd9528)] lg:block" />
            </div>
          </Reveal>

          <Person
            side="right"
            tone="bride"
            role="वधू"
            roleEn="Bride"
            monogram="अ"
            name="चि.सौ.कां. अनुजा"
            lines={[
              "कै. व्यंकटराव घुले यांची नात व",
              "सौ. अनिता व श्री. नरहरी व्यंकटराव घुले यांची ज्येष्ठ कन्या",
            ]}
            address="रा. श्रीनगर कॉलनी, नांदली रोड, अहमदपूर."
            delay={120}
          />
        </div>

        {/* Marathi quote */}
        <Reveal delay={80} className="relative mx-auto mt-16 max-w-3xl text-center sm:mt-20">
          <OrnateFrame roses={false} className="relative px-6 py-10 sm:px-12 sm:py-12">
            <img
              src={IMG.roseSpray}
              alt=""
              aria-hidden
              className="anim-float-sm pointer-events-none absolute -top-12 -left-10 w-44 -rotate-12 opacity-90 sm:w-56"
            />
            <img
              src={IMG.roseSpray}
              alt=""
              aria-hidden
              className="anim-float-sm pointer-events-none absolute -right-10 -bottom-12 w-44 -scale-x-100 -rotate-12 opacity-90 sm:w-56"
            />
            <span className="foil-deep font-display text-6xl leading-none opacity-60">“</span>
            <p className="foil-wine font-display text-2xl leading-[1.5] sm:text-4xl sm:leading-[1.45]">
              स्नेहबंध जुळती प्रीतीचे,
              <br />
              दोन मने एकत्र येती विवाहाचे
            </p>
            <div className="mt-5">
              <Divider tone="wine" width={300} />
            </div>
          </OrnateFrame>
        </Reveal>
      </div>
    </section>
  );
}
