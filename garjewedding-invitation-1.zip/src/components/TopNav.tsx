import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";

const LINKS = [
  { href: "#amantran", label: "आमंत्रण" },
  { href: "#varavadhu", label: "वर–वधू" },
  { href: "#muhurat", label: "मुहूर्त" },
  { href: "#haldi", label: "हळद" },
  { href: "#pravas", label: "प्रवास सूचना" },
  { href: "#vinit", label: "विनीत" },
];

export function TopNav({ active }: { active: boolean }) {
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);
  const [current, setCurrent] = useState<string>("#amantran");

  useEffect(() => {
    if (!active) return;
    let frame = 0;
    const onScroll = () => {
      if (frame) return;
      frame = window.requestAnimationFrame(() => {
        frame = 0;
        const y = window.scrollY;
        const h = document.documentElement.scrollHeight - window.innerHeight;
        setProgress(h > 0 ? Math.min(1, y / h) : 0);
        setVisible(y > 260);

        let nearest = LINKS[0].href;
        for (const l of LINKS) {
          const el = document.querySelector(l.href);
          if (el && (el as HTMLElement).getBoundingClientRect().top <= 180) nearest = l.href;
        }
        setCurrent(nearest);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [active]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-40 transition-all duration-700",
        visible ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
      )}
    >
      <div className="panel-wine border-b border-gold-400/40 backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-2.5 sm:px-6">
          <a href="#amantran" className="group flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-full border border-gold-300/60 bg-wine-800 font-display text-sm text-gold-200 transition-transform duration-500 group-hover:rotate-[18deg]">
              श्री
            </span>
            <span className="font-display text-base text-gold-100 sm:text-lg">
              पवन <span className="text-roseglow-400">✦</span> अनुजा
            </span>
          </a>

          <nav className="hidden items-center gap-1 lg:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className={cn(
                  "relative rounded-full px-3.5 py-1.5 text-sm transition-colors duration-300",
                  current === l.href
                    ? "text-gold-100"
                    : "text-gold-200/60 hover:text-gold-100"
                )}
              >
                {l.label}
                <span
                  className={cn(
                    "absolute inset-x-3 -bottom-0.5 h-px origin-left bg-gold-300/80 transition-transform duration-500",
                    current === l.href ? "scale-x-100" : "scale-x-0"
                  )}
                />
              </a>
            ))}
          </nav>

          <div className="text-right">
            <p className="font-latin text-[10px] tracking-[0.32em] text-gold-200/70 uppercase">
              10 Dec 2026
            </p>
            <p className="font-display text-xs text-gold-100/90 sm:text-sm">अहमदपूर</p>
          </div>
        </div>
        <div className="h-[2px] w-full bg-gold-400/15">
          <div
            className="h-full bg-[linear-gradient(90deg,#9b1b30,#d4af37,#f6e3a8)] shadow-[0_0_10px_rgba(212,175,55,0.8)]"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
      </div>
    </header>
  );
}
