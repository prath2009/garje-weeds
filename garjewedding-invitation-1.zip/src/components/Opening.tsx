import { useState } from "react";
import { IMG } from "@/lib/assets";
import { Divider, GoldDust, Petals, RoseCorner } from "@/components/ui";

export function Opening({ onEnter }: { onEnter: () => void }) {
  const [burst, setBurst] = useState(false);

  const handleEnter = () => {
    if (burst) return;
    setBurst(true);
    window.setTimeout(onEnter, 520);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-hidden bg-wine-950 transition-opacity duration-[900ms] ease-[cubic-bezier(.4,0,.2,1)]"
      style={{ opacity: burst ? 0 : 1 }}
    >
      {/* rose field */}
      <img
        src={IMG.rosesHero}
        alt=""
        className="anim-kenburns absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_38%,rgba(37,5,12,0.35),rgba(37,5,12,0.88)_72%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(37,5,12,0.75),transparent_28%,transparent_62%,rgba(37,5,12,0.9))]" />
      <div className="damask-dark absolute inset-0 opacity-40" />

      <Petals count={30} minSize={10} maxSize={26} minDur={9} maxDur={18} />
      <GoldDust count={34} />

      <RoseCorner className="-top-16 -left-16 w-44 opacity-95 sm:w-64 md:w-80" />
      <RoseCorner
        className="-right-16 -bottom-16 w-44 opacity-95 sm:w-64 md:w-80"
        flipX
        flipY
      />
      <RoseCorner
        className="-top-14 -right-14 w-32 rotate-90 opacity-70 sm:w-44"
        flipX
        float={false}
      />
      <RoseCorner
        className="-bottom-14 -left-14 w-32 -rotate-90 opacity-70 sm:w-44"
        flipY
        float={false}
      />

      {/* content */}
      <div
        className={`relative z-10 h-full w-full overflow-y-auto px-6 text-center ${
          burst ? "leaving" : ""
        }`}
      >
      <div className="flex min-h-full w-full flex-col items-center justify-center py-10">
        {/* Ganesh */}
        <div className="rise relative mb-2" style={{ animationDelay: "0.15s" }}>
          <div className="anim-halo absolute inset-0 -m-8 rounded-full bg-[radial-gradient(circle,rgba(246,227,168,0.42),transparent_62%)] blur-xl" />
          <div className="anim-spin-slow absolute -inset-4 rounded-full border border-dashed border-gold-300/40" />
          <div className="anim-spin-slower absolute -inset-10 rounded-full border border-gold-300/15" />
          <img
            src={IMG.ganesh}
            alt="श्री गजानन"
            className="anim-float relative w-32 sm:w-40 md:w-48"
            style={{
              mixBlendMode: "screen",
              maskImage:
                "radial-gradient(closest-side, #000 48%, rgba(0,0,0,0.9) 66%, rgba(0,0,0,0) 84%)",
              WebkitMaskImage:
                "radial-gradient(closest-side, #000 48%, rgba(0,0,0,0.9) 66%, rgba(0,0,0,0) 84%)",
              filter: "drop-shadow(0 0 26px rgba(246,227,168,0.5))",
            }}
          />
        </div>

        <p
          className="rise foil font-display text-lg tracking-[0.2em] sm:text-2xl md:text-3xl"
          style={{ animationDelay: "0.45s" }}
        >
          ॥ श्री गजानन प्रसन्न ॥
        </p>

        <div className="rise my-3 w-full max-w-xl" style={{ animationDelay: "0.6s" }}>
          <Divider tone="gold" width={520} className="opacity-90" />
        </div>

        <h1
          className="rise foil font-display text-[2.35rem] leading-[1.12] sm:text-7xl md:text-[6.5rem]"
          style={{ animationDelay: "0.75s", textShadow: "0 6px 40px rgba(212,175,55,0.28)" }}
        >
          शुभविवाह सोहळा
        </h1>

        <p
          className="rise mt-4 font-latin text-sm tracking-[0.5em] text-gold-100/85 uppercase sm:text-base"
          style={{ animationDelay: "0.95s" }}
        >
          Pavan <span className="text-roseglow-400">weds</span> Anuja
        </p>
        <p
          className="rise mt-2 font-latin text-xs tracking-[0.34em] text-gold-200/70 uppercase sm:text-sm"
          style={{ animationDelay: "1.05s" }}
        >
          Thursday · 10 December 2026 · Ahmedpur
        </p>

        <div className="rise mt-9 sm:mt-11" style={{ animationDelay: "1.25s" }}>
          <button
            type="button"
            onClick={handleEnter}
            className="btn-royal anim-glow group relative inline-flex items-center gap-3 rounded-full border border-gold-300/70 bg-[linear-gradient(120deg,#6f1020,#9b1b30_45%,#4f0c18)] px-9 py-4 font-display text-xl text-gold-100 sm:px-12 sm:text-2xl"
          >
            <span className="tracking-wide">आमंत्रण पहा</span>
            <svg viewBox="0 0 24 24" className="h-5 w-5 transition-transform duration-500 group-hover:translate-x-1.5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 12h15" />
              <path d="M13 6l6 6-6 6" />
            </svg>
          </button>
          <p className="mt-5 font-latin text-[11px] tracking-[0.4em] text-gold-100/50 uppercase">
            Digital Lagnpatrika
          </p>
        </div>
      </div>
      </div>

      {/* soft cinematic vignette */}
      <div className="pointer-events-none absolute inset-0 shadow-[inset_0_0_180px_60px_rgba(20,2,6,0.85)]" />
    </div>
  );
}
