import { useEffect, useState } from "react";
import { MUHURTA } from "@/lib/assets";
import { Divider, Eyebrow, GoldDust, OrnateFrame, Reveal, RoseCorner } from "@/components/ui";
import { cn } from "@/utils/cn";

const DEV = ["०", "१", "२", "३", "४", "५", "६", "७", "८", "९"];
const toDev = (n: number) =>
  String(n)
    .padStart(2, "0")
    .split("")
    .map((d) => DEV[Number(d)])
    .join("");

function remaining(target: number) {
  const ms = Math.max(0, target - Date.now());
  const s = Math.floor(ms / 1000);
  return {
    days: Math.floor(s / 86400),
    hours: Math.floor((s % 86400) / 3600),
    minutes: Math.floor((s % 3600) / 60),
    seconds: s % 60,
    over: ms === 0,
  };
}

function Countdown() {
  const [t, setT] = useState(() => remaining(MUHURTA));

  useEffect(() => {
    const id = window.setInterval(() => setT(remaining(MUHURTA)), 1000);
    return () => window.clearInterval(id);
  }, []);

  const cells = [
    { v: t.days, label: "दिवस", en: "Days", big: true },
    { v: t.hours, label: "तास", en: "Hours" },
    { v: t.minutes, label: "मिनिटे", en: "Minutes" },
    { v: t.seconds, label: "सेकंद", en: "Seconds" },
  ];

  return (
    <div className="mt-4">
      <div className="flex flex-wrap items-stretch justify-center gap-3 sm:gap-4">
        {cells.map((c, i) => (
          <div key={c.en} className="flex items-stretch gap-3 sm:gap-4">
            <div
              className={cn(
                "relative flex min-w-[4.35rem] flex-col items-center justify-center overflow-hidden rounded-2xl border border-gold-400/45 bg-[linear-gradient(160deg,rgba(125,20,37,0.85),rgba(37,5,12,0.9))] px-2.5 py-4 shadow-[0_22px_44px_-26px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(246,227,168,0.25)] sm:min-w-[7.5rem] sm:px-6 sm:py-6",
                c.big && "sm:min-w-[9rem] border-gold-300/70"
              )}
            >
              <div className="damask-dark pointer-events-none absolute inset-0 opacity-60" />
              <span
                key={c.v}
                className={cn(
                  "anim-tick relative font-display leading-none text-gold-100",
                  c.big ? "text-4xl sm:text-7xl" : "text-3xl sm:text-6xl"
                )}
                style={{ textShadow: "0 0 26px rgba(212,175,55,0.45)" }}
              >
                {toDev(c.v)}
              </span>
              <span className="relative mt-1.5 font-display text-xs tracking-wide text-gold-200/90 sm:mt-2 sm:text-base">
                {c.label}
              </span>
              <span className="relative font-latin text-[9px] tracking-[0.34em] text-gold-200/45 uppercase">
                {c.en}
              </span>
              <span className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[linear-gradient(90deg,transparent,rgba(246,227,168,0.9),transparent)]" />
            </div>
            {i < cells.length - 1 && (
              <span className="hidden self-center font-display text-2xl text-gold-400/60 sm:block">
                :
              </span>
            )}
          </div>
        ))}
      </div>
      <p className="mt-4 text-center font-latin text-[10px] tracking-[0.4em] text-gold-200/50 uppercase">
        {t.over ? "शुभविवाह सोहळा संपन्न" : "Countdown to the Muhurta"}
      </p>
    </div>
  );
}

const ROWS = [
  { k: "मिती", v: "मार्गशीर्ष शु. प्रतिपदा शके १९४८", en: "Tithi" },
  { k: "वार", v: "गुरुवार, दिनांक १० डिसेंबर २०२६", en: "Date" },
  { k: "वेळ", v: "दुपारी १२ वाजून १९ मिनिटांनी.", en: "Time" },
];

function downloadIcs() {
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Garje Parivar//Digital Lagnpatrika//MR",
    "CALSCALE:GREGORIAN",
    "BEGIN:VEVENT",
    "UID:pavan-anuja-vivaha-2026@lagnpatrika",
    "DTSTAMP:20260101T000000Z",
    "DTSTART:20261210T064900Z",
    "DTEND:20261210T103000Z",
    "SUMMARY:शुभविवाह सोहळा — चि. पवन व चि.सौ.कां. अनुजा",
    "LOCATION:विराज मंगल कार्यालय\\, अहमदपूर",
    "DESCRIPTION:मिती मार्गशीर्ष शु. प्रतिपदा शके १९४८. दुपारी १२ वाजून १९ मिनिटांनी मुहूर्त. समस्त गर्जे परिवाराकडून आग्रहाचे आमंत्रण!",
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
  const url = URL.createObjectURL(new Blob([ics], { type: "text/calendar;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "pavan-anuja-shubhvivah.ics";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function Muhurat() {
  return (
    <section id="muhurat" className="relative overflow-hidden">
      <div className="panel-wine absolute inset-0" />
      <div className="damask-dark absolute inset-0 opacity-70" />
      <div className="absolute inset-0 bg-[radial-gradient(90%_60%_at_50%_0%,rgba(212,175,55,0.16),transparent_60%)]" />
      <GoldDust count={30} />
      <RoseCorner className="-top-16 -left-16 w-52 opacity-95 sm:w-72" />
      <RoseCorner className="-right-16 -bottom-16 w-52 opacity-95 sm:w-72" flipX flipY />
      <span className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[linear-gradient(90deg,transparent,#d4af37,transparent)]" />
      <span className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-[linear-gradient(90deg,transparent,#d4af37,transparent)]" />

      <div className="relative mx-auto max-w-5xl px-4 py-20 sm:px-6 sm:py-28">
        <Reveal className="text-center">
          <Eyebrow tone="gold">The Auspicious Muhurta</Eyebrow>
          <h2 className="foil mt-3 font-display text-[2.15rem] leading-tight sm:text-6xl md:text-7xl">
            शुभविवाह मुहूर्त
          </h2>
          <p className="mt-3 font-latin text-[11px] tracking-[0.4em] text-gold-200/60 uppercase">
            Thursday · 10 December 2026 · 12:19 PM
          </p>
        </Reveal>

        <Reveal dir="up" delay={120} className="mt-10">
          <OrnateFrame
            roses={false}
            tone="wine"
            className="rounded-[28px] border border-gold-400/45 bg-[linear-gradient(160deg,rgba(79,12,24,0.9),rgba(37,5,12,0.94))] px-5 py-9 sm:px-10 sm:py-12"
          >
            <div className="divide-y divide-gold-400/25">
              {ROWS.map((r) => (
                <div
                  key={r.k}
                  className="group flex flex-col items-center gap-1 py-4 text-center transition-colors duration-500 sm:flex-row sm:justify-between sm:gap-6 sm:text-left"
                >
                  <div className="flex items-baseline gap-3">
                    <span className="foil-soft font-display text-2xl sm:text-3xl">{r.k}</span>
                    <span className="font-latin text-[10px] tracking-[0.34em] text-gold-200/45 uppercase">
                      {r.en}
                    </span>
                  </div>
                  <span className="text-lg text-ivory/90 transition-colors duration-500 group-hover:text-gold-100 sm:text-2xl sm:font-display">
                    {r.v}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-6 rounded-2xl border border-gold-400/40 bg-[radial-gradient(120%_120%_at_50%_0%,rgba(155,27,48,0.55),rgba(37,5,12,0.6))] px-5 py-6 text-center">
              <p className="font-latin text-[10px] tracking-[0.42em] text-gold-200/60 uppercase">
                Wedding Venue · विवाह स्थळ
              </p>
              <p className="foil mt-2 font-display text-2xl leading-snug sm:text-4xl">
                विराज मंगल कार्यालय, अहमदपूर.
              </p>
              <div className="mt-4 flex items-center justify-center gap-2 text-gold-100/70">
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.4">
                  <path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11z" />
                  <circle cx="12" cy="10" r="2.4" />
                </svg>
                <span className="text-sm">अहमदपूर, जि. लातूर</span>
              </div>
            </div>
          </OrnateFrame>
        </Reveal>

        <Reveal dir="up" delay={200} className="mt-14">
          <div className="text-center">
            <Divider tone="gold" width={420} className="opacity-80" />
            <h3 className="foil mt-4 font-display text-2xl sm:text-4xl">
              मुहूर्ताची प्रतीक्षा…
            </h3>
          </div>
          <Countdown />
          <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
            <button
              type="button"
              onClick={downloadIcs}
              className="btn-royal inline-flex items-center gap-2.5 rounded-full border border-gold-300/60 bg-[linear-gradient(120deg,#6f1020,#9b1b30_50%,#4f0c18)] px-7 py-3.5 font-display text-lg text-gold-100"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.5">
                <rect x="3" y="5" width="18" height="16" rx="2.5" />
                <path d="M3 10h18M8 3v4M16 3v4M12 14v4M10 16h4" />
              </svg>
              कॅलेंडरमध्ये जोडा
            </button>
            <a
              href="#pravas"
              className="group inline-flex items-center gap-2 rounded-full border border-gold-300/35 px-7 py-3.5 font-display text-lg text-gold-100/85 transition-all duration-500 hover:border-gold-300/80 hover:text-gold-50"
            >
              प्रवास सूचना पहा
              <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
                <path d="M4 12h15M13 6l6 6-6 6" />
              </svg>
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
