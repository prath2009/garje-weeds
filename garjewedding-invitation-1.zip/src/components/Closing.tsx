import { useEffect, useState } from "react";
import { CONTACT, IMG } from "@/lib/assets";
import { Divider, Eyebrow, GoldDust, Petals, Reveal, RoseCorner } from "@/components/ui";

export function Family() {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const id = window.setTimeout(() => setCopied(false), 2400);
    return () => window.clearTimeout(id);
  }, [copied]);

  const share = async () => {
    const data = {
      title: "शुभविवाह सोहळा — चि. पवन व चि.सौ.कां. अनुजा",
      text: "दिनांक १० डिसेंबर २०२६, विराज मंगल कार्यालय, अहमदपूर. समस्त गर्जे परिवाराकडून आग्रहाचे आमंत्रण!",
      url: window.location.href,
    };
    try {
      if (navigator.share) {
        await navigator.share(data);
        return;
      }
      await navigator.clipboard.writeText(`${data.text}\n${data.url}`);
      setCopied(true);
    } catch {
      setCopied(true);
    }
  };

  return (
    <section id="vinit" className="relative overflow-hidden">
      <img
        src={IMG.rosesHero}
        alt=""
        aria-hidden
        className="anim-kenburns absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-[radial-gradient(110%_80%_at_50%_45%,rgba(37,5,12,0.72),rgba(37,5,12,0.94)_75%)]" />
      <div className="damask-dark absolute inset-0 opacity-45" />
      <Petals count={16} minSize={8} maxSize={20} minDur={12} maxDur={22} />
      <GoldDust count={26} />
      <span className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[linear-gradient(90deg,transparent,#d4af37,transparent)]" />

      <RoseCorner className="-top-16 -left-16 w-52 opacity-95 sm:w-72" />
      <RoseCorner className="-right-16 -top-10 w-44 rotate-90 opacity-80 sm:w-60" flipX float={false} />
      <RoseCorner className="-bottom-16 -right-16 w-52 opacity-95 sm:w-72" flipX flipY />

      <div className="relative mx-auto max-w-4xl px-4 py-20 text-center sm:px-6 sm:py-28">
        <Reveal dir="up">
          <Eyebrow tone="gold">With Love, From The Family</Eyebrow>
          <h2 className="foil mt-4 font-display text-5xl leading-none sm:text-7xl md:text-8xl">
            विनीत
          </h2>
          <div className="mt-5">
            <Divider tone="gold" width={420} className="opacity-85" />
          </div>
        </Reveal>

        <Reveal dir="up" delay={140} className="mt-10">
          <p className="font-display text-3xl leading-snug text-gold-100 sm:text-5xl">
            सौ. अलका व प्रभाकर जयसिंगराव गर्जे
          </p>
          <p className="foil-soft mt-3 font-display text-2xl sm:text-4xl">
            आणि समस्त गर्जे परिवार
          </p>
        </Reveal>

        <Reveal dir="zoom" delay={240} className="mt-12">
          <div className="relative mx-auto max-w-2xl rounded-[26px] border border-gold-300/50 bg-[linear-gradient(150deg,rgba(125,20,37,0.72),rgba(37,5,12,0.8))] px-6 py-9 shadow-[0_30px_70px_-34px_rgba(0,0,0,0.9),inset_0_1px_0_rgba(246,227,168,0.25)] sm:px-12">
            <div className="pointer-events-none absolute inset-[8px] rounded-[20px] border border-dashed border-gold-300/30" />
            <span className="foil-deep absolute -top-6 left-6 font-display text-7xl leading-none opacity-70">
              “
            </span>
            <p className="foil relative font-display text-2xl leading-snug sm:text-4xl">
              समस्त गर्जे परिवाराकडून आग्रहाचे आमंत्रण!
            </p>
            <p className="relative mt-4 font-latin text-[10px] tracking-[0.4em] text-gold-200/55 uppercase">
              You are lovingly invited
            </p>
          </div>
        </Reveal>

        <Reveal dir="up" delay={320} className="mt-12">
          <p className="font-latin text-[10px] tracking-[0.42em] text-gold-200/60 uppercase">
            For Invitations &amp; Enquiries
          </p>
          <p className="mt-3 font-display text-2xl text-gold-100 sm:text-3xl">
            {CONTACT.name} :{" "}
            <a
              href={`tel:${CONTACT.phone}`}
              className="foil transition-[filter] duration-500 hover:brightness-125"
            >
              {CONTACT.phone}
            </a>
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <a
              href={`tel:${CONTACT.phone}`}
              className="btn-royal inline-flex items-center gap-2.5 rounded-full border border-gold-300/70 bg-[linear-gradient(120deg,#6f1020,#9b1b30_50%,#4f0c18)] px-7 py-3.5 font-display text-lg text-gold-100"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
                <path d="M5 3h3.5l1.8 4.3-2.2 1.6a12.5 12.5 0 0 0 6 6l1.6-2.2L20 14.5V18a2 2 0 0 1-2.2 2A15.8 15.8 0 0 1 3 5.2 2 2 0 0 1 5 3z" />
              </svg>
              संपर्क साधा
            </a>
            <a
              href={`https://wa.me/91${CONTACT.phone}`}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-2.5 rounded-full border border-gold-300/40 px-7 py-3.5 font-display text-lg text-gold-100/85 transition-all duration-500 hover:-translate-y-0.5 hover:border-gold-200/85 hover:text-gold-50"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-gold-200" fill="currentColor">
                <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm5.3 14.1c-.2.6-1.2 1.2-1.7 1.2-.5.1-1 .1-1.7-.1a12 12 0 0 1-4.9-3.6 9.6 9.6 0 0 1-1.7-3.3c-.1-.6 0-1.2.4-1.7.2-.3.5-.5.8-.5h.6c.2 0 .4.1.5.4l.8 1.9c.1.2 0 .4-.1.6l-.4.5c-.1.2-.2.3 0 .5.5.9 1.1 1.5 2 2 .3.2.4.1.6-.1l.6-.7c.2-.2.3-.2.5-.1l1.8.9c.3.1.3.3.3.5a2.6 2.6 0 0 1-.4 1z" />
              </svg>
              व्हॉट्सॲप करा
            </a>
            <button
              type="button"
              onClick={share}
              className="group relative inline-flex items-center gap-2.5 rounded-full border border-gold-300/40 px-7 py-3.5 font-display text-lg text-gold-100/85 transition-all duration-500 hover:-translate-y-0.5 hover:border-gold-200/85 hover:text-gold-50"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-gold-200" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
                <circle cx="18" cy="5" r="2.6" />
                <circle cx="6" cy="12" r="2.6" />
                <circle cx="18" cy="19" r="2.6" />
                <path d="M8.4 10.8l7.2-4.2M8.4 13.2l7.2 4.2" />
              </svg>
              {copied ? "लिंक कॉपी झाली!" : "आमंत्रण पाठवा"}
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-gold-400/40 bg-[linear-gradient(180deg,#f8f0de,#eddcba)]">
      <div className="damask absolute inset-0 opacity-60" />
      <img
        src={IMG.roseSpray}
        alt=""
        aria-hidden
        className="anim-float-sm pointer-events-none absolute -top-8 left-1/2 w-64 -translate-x-1/2 opacity-80 sm:w-80"
      />
      <div className="relative mx-auto max-w-5xl px-4 pt-24 pb-10 text-center sm:px-6">
        <p className="foil-deep font-display text-3xl sm:text-4xl">शुभविवाह सोहळा</p>
        <p className="mt-2 font-display text-xl text-wine-800 sm:text-2xl">
          चि. पवन <span className="text-ruby-600">✦</span> चि.सौ.कां. अनुजा
        </p>
        <p className="mt-2 text-sm text-wine-800/70">
          गुरुवार, दिनांक १० डिसेंबर २०२६ · दुपारी १२ वाजून १९ मिनिटांनी · विराज मंगल कार्यालय,
          अहमदपूर.
        </p>

        <div className="my-7">
          <Divider tone="wine" width={380} />
        </div>

        <div className="flex flex-col items-center gap-2">
          <p className="font-latin text-[10px] tracking-[0.42em] text-gold-600 uppercase">
            Designed &amp; Created by
          </p>
          <p className="foil-deep font-display text-2xl tracking-[0.16em] sm:text-3xl">
            GARJE PRATU
          </p>
          <div className="mt-2 flex items-center gap-2 text-wine-700/60">
            <span className="h-px w-10 bg-gold-500/50" />
            <svg viewBox="0 0 24 24" className="h-4 w-4 text-ruby-600" fill="currentColor">
              <path d="M12 21s-7.5-4.7-9.3-9A5.4 5.4 0 0 1 12 6.3 5.4 5.4 0 0 1 21.3 12c-1.8 4.3-9.3 9-9.3 9z" />
            </svg>
            <span className="h-px w-10 bg-gold-500/50" />
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-wine-800/60">
          <a href="#amantran" className="transition-colors hover:text-ruby-600">
            आमंत्रण
          </a>
          <a href="#varavadhu" className="transition-colors hover:text-ruby-600">
            वर–वधू
          </a>
          <a href="#muhurat" className="transition-colors hover:text-ruby-600">
            मुहूर्त
          </a>
          <a href="#haldi" className="transition-colors hover:text-ruby-600">
            हळद
          </a>
          <a href="#pravas" className="transition-colors hover:text-ruby-600">
            विशेष सूचना
          </a>
          <a href={`tel:${CONTACT.phone}`} className="transition-colors hover:text-ruby-600">
            {CONTACT.name} : {CONTACT.phone}
          </a>
        </div>

        <p className="mt-6 font-latin text-[10px] tracking-[0.32em] text-wine-700/45 uppercase">
          © 2026 Samasta Garje Parivar · Digital Lagnpatrika
        </p>
      </div>
    </footer>
  );
}
