import { IMG } from "@/lib/assets";
import { Divider, OrnateFrame, Reveal, useTilt } from "@/components/ui";

const MARQUEE = [
  "शुभविवाह सोहळा",
  "चि. पवन ✦ चि.सौ.कां. अनुजा",
  "गुरुवार · दिनांक १० डिसेंबर २०२६",
  "विराज मंगल कार्यालय, अहमदपूर",
  "समस्त गर्जे परिवार",
];

function Marquee() {
  const row = [...MARQUEE, ...MARQUEE];
  return (
    <div className="panel-wine relative mt-14 overflow-hidden border-y border-gold-400/40 py-3 sm:py-4">
      <div className="marquee-track items-center">
        {[0, 1].map((dup) => (
          <div key={dup} className="flex shrink-0 items-center gap-10 pr-10">
            {row.map((t, i) => (
              <span key={`${dup}-${i}`} className="flex items-center gap-10 whitespace-nowrap">
                <span className="font-display text-base tracking-wide text-gold-100/90 sm:text-xl">
                  {t}
                </span>
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 shrink-0 text-roseglow-400" fill="currentColor">
                  <path d="M12 21s-7.5-4.7-9.3-9A5.4 5.4 0 0 1 12 6.3 5.4 5.4 0 0 1 21.3 12c-1.8 4.3-9.3 9-9.3 9z" />
                </svg>
              </span>
            ))}
          </div>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-[linear-gradient(90deg,#25050c,transparent)]" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-[linear-gradient(270deg,#25050c,transparent)]" />
    </div>
  );
}

export function InvitationHero() {
  const tiltRef = useTilt<HTMLDivElement>(3);
  return (
    <section id="amantran" className="relative px-4 pt-8 sm:px-6 sm:pt-14">
      <div className="mx-auto max-w-5xl">
        <Reveal dir="zoom">
          <div ref={tiltRef} className="tilt">
          <OrnateFrame className="panel-gold ring-gold rounded-[30px] px-4 py-12 sm:px-10 sm:py-16 md:px-16 md:py-20">
            {/* Ganesh medallion */}
            <div className="relative mx-auto mb-6 h-24 w-24 sm:h-28 sm:w-28">
              <div className="anim-spin-slow absolute inset-0 rounded-full border border-dashed border-gold-500/50" />
              <div className="absolute inset-[7px] rounded-full bg-[radial-gradient(circle_at_50%_35%,#7d1425,#3a0812_70%)] shadow-[inset_0_0_18px_rgba(0,0,0,0.6)]" />
              <div className="anim-halo absolute -inset-4 rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.35),transparent_65%)] blur-md" />
              <img
                src={IMG.ganesh}
                alt="श्री गजानन"
                className="anim-float-sm absolute inset-0 m-auto h-[86%] w-[86%] object-contain"
                style={{
                  mixBlendMode: "screen",
                  maskImage:
                    "radial-gradient(closest-side, #000 52%, rgba(0,0,0,0.9) 70%, rgba(0,0,0,0) 88%)",
                  WebkitMaskImage:
                    "radial-gradient(closest-side, #000 52%, rgba(0,0,0,0.9) 70%, rgba(0,0,0,0) 88%)",
                  filter: "drop-shadow(0 0 12px rgba(246,227,168,0.45))",
                }}
              />
            </div>

            <p className="foil-deep text-center font-display text-base tracking-[0.18em] sm:text-xl">
              ॥ श्री गजानन प्रसन्न ॥
            </p>

            <h1 className="foil-deep mt-3 text-center font-display text-[2.4rem] leading-[1.1] sm:text-7xl md:text-[5.5rem]">
              शुभविवाह सोहळा
            </h1>

            <p className="mt-3 text-center font-latin text-[11px] tracking-[0.46em] text-wine-700/70 uppercase sm:text-xs">
              Royal Wedding Invitation · Lagnpatrika
            </p>

            <div className="my-6">
              <Divider tone="wine" width={560} />
            </div>

            {/* names */}
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row sm:gap-8">
              <div className="text-center">
                <p className="font-latin text-[10px] tracking-[0.4em] text-gold-600 uppercase">The Groom</p>
                <p className="foil-wine font-display text-3xl sm:text-5xl">चि. पवन</p>
              </div>

              <span className="relative grid h-14 w-14 shrink-0 place-items-center sm:h-16 sm:w-16">
                <span className="anim-spin-slow absolute inset-0 rounded-full border border-dashed border-gold-500/60" />
                <span className="absolute inset-1.5 rounded-full bg-[radial-gradient(circle_at_35%_30%,#fff6dd,#e3c678_55%,#a67c1c)] shadow-[0_6px_18px_-6px_rgba(122,84,18,0.8)]" />
                <svg viewBox="0 0 24 24" className="relative h-6 w-6 text-wine-800" fill="currentColor">
                  <path d="M12 21s-7.5-4.7-9.3-9A5.4 5.4 0 0 1 12 6.3 5.4 5.4 0 0 1 21.3 12c-1.8 4.3-9.3 9-9.3 9z" />
                </svg>
              </span>

              <div className="text-center">
                <p className="font-latin text-[10px] tracking-[0.4em] text-gold-600 uppercase">The Bride</p>
                <p className="foil-wine font-display text-3xl sm:text-5xl">चि.सौ.कां. अनुजा</p>
              </div>
            </div>

            {/* date strip */}
            <div className="mt-9 flex flex-wrap items-stretch justify-center gap-3 sm:gap-0">
              {[
                { k: "वार", v: "गुरुवार" },
                { k: "दिनांक", v: "१० डिसेंबर २०२६" },
                { k: "मुहूर्त", v: "दुपारी १२:१९" },
              ].map((item, i) => (
                <div
                  key={item.k}
                  className="group relative flex min-w-[9.5rem] flex-1 flex-col items-center rounded-2xl border border-gold-400/45 bg-[linear-gradient(150deg,rgba(255,250,241,0.9),rgba(240,220,162,0.35))] px-5 py-4 transition-all duration-500 hover:-translate-y-1 hover:border-gold-500/80 hover:shadow-[0_18px_38px_-22px_rgba(58,8,18,0.7)] sm:rounded-none sm:border-0 sm:bg-transparent sm:px-8"
                >
                  <span className="font-latin text-[10px] tracking-[0.34em] text-gold-600 uppercase">
                    {item.k}
                  </span>
                  <span className="mt-1 font-display text-xl text-wine-800 transition-colors duration-500 group-hover:text-ruby-600 sm:text-2xl">
                    {item.v}
                  </span>
                  {i < 2 && (
                    <span className="absolute top-1/2 -right-px hidden h-10 w-px -translate-y-1/2 bg-[linear-gradient(180deg,transparent,#bd9528,transparent)] sm:block" />
                  )}
                </div>
              ))}
            </div>

            {/* venue */}
            <div className="mt-8 flex items-center justify-center gap-3 text-wine-800">
              <svg viewBox="0 0 24 24" className="h-5 w-5 text-gold-600" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11z" />
                <circle cx="12" cy="10" r="2.6" />
              </svg>
              <p className="font-display text-xl sm:text-2xl">विराज मंगल कार्यालय, अहमदपूर</p>
            </div>

            <img
              src={IMG.roseSpray}
              alt=""
              aria-hidden
              className="anim-float-sm pointer-events-none absolute -bottom-10 left-1/2 w-64 -translate-x-1/2 opacity-95 sm:w-80"
            />
          </OrnateFrame>
          </div>
        </Reveal>

        {/* scroll cue */}
        <Reveal delay={400} className="mt-20 flex justify-center sm:mt-16">
          <a href="#varavadhu" className="group flex flex-col items-center gap-2 text-wine-700/70">
            <span className="font-latin text-[10px] tracking-[0.4em] uppercase transition-colors group-hover:text-ruby-600">
              Scroll
            </span>
            <span className="grid h-9 w-6 place-items-start rounded-full border border-gold-500/60 p-1">
              <span className="h-2 w-1 animate-bounce rounded-full bg-gold-500" />
            </span>
          </a>
        </Reveal>
      </div>

      <Marquee />
    </section>
  );
}
