import { IMG } from "@/lib/assets";
import { Divider, Eyebrow, GoldDust, OrnateFrame, Reveal, RoseCorner } from "@/components/ui";

/* ------------------------------------------------------------------ */
/* हळदी समारंभ                                                         */
/* ------------------------------------------------------------------ */
export function Haldi() {
  return (
    <section id="haldi" className="relative px-4 py-16 sm:px-6 sm:py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal className="text-center">
          <Eyebrow tone="wine">Haldi Ceremony</Eyebrow>
          <h2 className="foil-deep mt-3 font-display text-4xl sm:text-6xl">हळदी समारंभ</h2>
        </Reveal>

        <div className="mt-12 grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-14">
          {/* illustration */}
          <Reveal dir="left" className="relative mx-auto w-full max-w-sm">
            <div className="anim-halo absolute -inset-6 rounded-full bg-[radial-gradient(circle,rgba(224,178,52,0.4),transparent_64%)] blur-xl" />
            <div className="anim-spin-slow absolute -inset-3 rounded-full border border-dashed border-gold-500/45" />
            <div className="relative aspect-square overflow-hidden rounded-full border-2 border-gold-400/70 bg-[radial-gradient(circle_at_50%_35%,#fffaf1,#f4e6c4_55%,#ead6a8)] shadow-[0_30px_60px_-30px_rgba(58,8,18,0.7)]">
              <div className="damask absolute inset-0 opacity-60" />
              <img
                src={IMG.haldi}
                alt="हळदी समारंभ"
                className="anim-float relative z-10 h-full w-full object-contain p-6"
              />
            </div>
            <img
              src={IMG.roseSpray}
              alt=""
              aria-hidden
              className="anim-float-sm absolute -right-8 -bottom-8 z-20 w-40 rotate-6 sm:w-48"
            />
          </Reveal>

          {/* details */}
          <Reveal dir="right" delay={120}>
            <OrnateFrame
              roses={false}
              className="panel-gold ring-gold rounded-[28px] px-6 py-10 sm:px-10 sm:py-12"
            >
              <div className="flex items-start gap-4">
                <span className="mt-1 grid h-12 w-12 shrink-0 place-items-center rounded-full border border-gold-400/70 bg-[radial-gradient(circle_at_35%_30%,#ffe9a8,#e0b234_60%,#a67c1c)] shadow-[0_10px_22px_-10px_rgba(122,84,18,0.9)]">
                  <svg viewBox="0 0 24 24" className="h-6 w-6 text-wine-800" fill="currentColor">
                    <path d="M12 3c2.6 3.2 3.9 5.7 3.9 7.8a3.9 3.9 0 1 1-7.8 0C8.1 8.7 9.4 6.2 12 3z" />
                    <path d="M5 15.5c1.4 3.6 4.1 5.5 7 5.5s5.6-1.9 7-5.5c-1.9 1.3-4.1 2-7 2s-5.1-.7-7-2z" opacity=".65" />
                  </svg>
                </span>
                <div>
                  <h3 className="font-display text-3xl text-wine-800 sm:text-4xl">हळदी समारंभ</h3>
                  <p className="mt-1 font-latin text-[10px] tracking-[0.38em] text-gold-600 uppercase">
                    Wednesday Evening · Haldi
                  </p>
                </div>
              </div>

              <div className="mt-7 space-y-4">
                {[
                  { k: "वार", v: "बुधवार, दिनांक ०९ डिसेंबर २०२६" },
                  { k: "वेळ", v: "सायंकाळी ६:०० नंतर." },
                ].map((r) => (
                  <div
                    key={r.k}
                    className="group flex flex-col gap-0.5 rounded-2xl border border-gold-400/40 bg-[linear-gradient(120deg,rgba(255,250,241,0.85),rgba(240,220,162,0.3))] px-5 py-4 transition-all duration-500 hover:-translate-y-0.5 hover:border-gold-500/75 hover:shadow-[0_18px_36px_-24px_rgba(58,8,18,0.8)] sm:flex-row sm:items-center sm:gap-6"
                  >
                    <span className="foil-deep w-16 shrink-0 font-display text-xl">{r.k}</span>
                    <span className="text-lg text-wine-800 transition-colors duration-500 group-hover:text-ruby-600 sm:text-xl sm:font-display">
                      {r.v}
                    </span>
                  </div>
                ))}
              </div>

              {/* mini timeline */}
              <div className="mt-9">
                <p className="font-latin text-[10px] tracking-[0.38em] text-gold-600 uppercase">
                  Programme
                </p>
                <div className="mt-4 flex items-center gap-3">
                  {[
                    { d: "०९ डिसेंबर", t: "हळदी समारंभ", s: "सायंकाळी ६:०० नंतर" },
                    { d: "१० डिसेंबर", t: "शुभविवाह मुहूर्त", s: "दुपारी १२:१९ वाजता" },
                  ].map((n, i) => (
                    <div key={n.d} className="flex flex-1 items-center gap-3">
                      <div className="flex-1 rounded-xl border border-gold-400/40 bg-ivory/70 px-3 py-3 text-center">
                        <p className="font-latin text-[10px] tracking-[0.24em] text-gold-600 uppercase">
                          {n.d}
                        </p>
                        <p className="font-display text-base text-wine-800 sm:text-lg">{n.t}</p>
                        <p className="text-xs text-wine-700/70">{n.s}</p>
                      </div>
                      {i === 0 && (
                        <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 text-gold-500" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
                          <path d="M4 12h15M13 6l6 6-6 6" />
                        </svg>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8">
                <Divider tone="wine" width={300} />
              </div>
              <p className="mt-4 text-center text-[15px] leading-relaxed text-wine-800/75">
                हळदीच्या या मंगल प्रसंगी आपल्या उपस्थितीने सोहळा अधिक उजळून निघेल.
              </p>
            </OrnateFrame>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* विशेष सूचना — ट्रॅव्हल्स (बस)                                          */
/* ------------------------------------------------------------------ */
function GoldenBus() {
  return (
    <div className="relative mx-auto w-full max-w-[19rem]">
      <div className="anim-halo absolute -inset-6 rounded-full bg-[radial-gradient(circle,rgba(246,227,168,0.35),transparent_66%)] blur-lg" />
      <svg viewBox="0 0 220 120" className="anim-float-sm relative w-full" aria-hidden>
        <defs>
          <linearGradient id="busGold" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#fff3cd" />
            <stop offset="38%" stopColor="#e3c678" />
            <stop offset="72%" stopColor="#d4af37" />
            <stop offset="100%" stopColor="#9a761c" />
          </linearGradient>
          <linearGradient id="busGlass" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#f7e6b4" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#bd9528" stopOpacity="0.55" />
          </linearGradient>
        </defs>
        {/* road */}
        <path
          d="M6 100h208"
          stroke="url(#busGold)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeDasharray="16 12"
          opacity="0.65"
        />
        {/* body */}
        <rect x="18" y="26" width="164" height="58" rx="14" fill="url(#busGold)" />
        <path d="M182 40h14a10 10 0 0 1 10 10v26a8 8 0 0 1-8 8h-16z" fill="url(#busGold)" />
        {/* windows */}
        <g fill="url(#busGlass)">
          <rect x="30" y="36" width="30" height="22" rx="5" />
          <rect x="66" y="36" width="30" height="22" rx="5" />
          <rect x="102" y="36" width="30" height="22" rx="5" />
          <path d="M140 36h34l14 12v10h-48z" />
        </g>
        {/* trims */}
        <rect x="18" y="64" width="188" height="4" fill="#8a6617" opacity="0.55" />
        <rect x="26" y="72" width="40" height="6" rx="3" fill="#fff6d8" opacity="0.5" />
        <circle cx="200" cy="74" r="4.5" fill="#fff6d8" />
        {/* wheels */}
        <g>
          <circle cx="58" cy="88" r="13" fill="#3a0812" stroke="url(#busGold)" strokeWidth="3" />
          <circle cx="58" cy="88" r="4" fill="url(#busGold)" />
          <circle cx="166" cy="88" r="13" fill="#3a0812" stroke="url(#busGold)" strokeWidth="3" />
          <circle cx="166" cy="88" r="4" fill="url(#busGold)" />
        </g>
        {/* speed lines */}
        <g stroke="url(#busGold)" strokeWidth="2.5" strokeLinecap="round" opacity="0.6">
          <path d="M2 44h10M0 56h14M4 68h8" />
        </g>
      </svg>
    </div>
  );
}

export function Travel() {
  const chips = [
    { k: "दिनांक", v: "गुरूवार, दि. १०/१२/२०२६" },
    { k: "वेळ", v: "सकाळी ७:३० वाजता" },
    { k: "प्रस्थान", v: "शिंदेनगर, बीड" },
  ];

  return (
    <section id="pravas" className="relative overflow-hidden px-4 py-16 sm:px-6 sm:py-24">
      <div className="mx-auto max-w-6xl">
        <Reveal dir="up">
          <div className="panel-wine relative overflow-hidden rounded-[32px] border border-gold-400/50 px-5 py-12 sm:px-12 sm:py-16">
            <div className="damask-dark absolute inset-0 opacity-70" />
            <div className="absolute inset-0 bg-[radial-gradient(80%_60%_at_20%_0%,rgba(212,175,55,0.2),transparent_60%)]" />
            <GoldDust count={20} />
            <RoseCorner className="-top-14 -right-14 w-44 opacity-90 sm:w-56" flipX />
            <RoseCorner className="-bottom-14 -left-14 w-44 opacity-90 sm:w-56" flipY />
            <span className="pointer-events-none absolute inset-x-8 top-0 h-px bg-[linear-gradient(90deg,transparent,rgba(246,227,168,0.9),transparent)]" />

            <div className="relative grid items-center gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
              <div>
                <GoldenBus />
                <p className="mt-5 text-center font-latin text-[10px] tracking-[0.42em] text-gold-200/60 uppercase">
                  Travels · Bus Facility
                </p>
              </div>

              <div>
                <Eyebrow tone="gold">Special Request</Eyebrow>
                <h2 className="foil mt-3 font-display text-4xl leading-tight sm:text-5xl md:text-6xl">
                  विशेष सूचना
                </h2>

                <div className="mt-6 space-y-4 text-lg leading-relaxed text-ivory/90 sm:text-xl">
                  <p>
                    गुरूवार, दि. १०/१२/२०२६ रोजी सकाळी ७:३० वाजता शिंदेनगर, बीड येथून लग्न
                    सोहळ्यासाठी ट्रॅव्हल्स (बस) निघेल.
                  </p>
                  <p className="foil-soft font-display text-xl sm:text-2xl">
                    तरी सर्व आप्तेष्टांनी वेळेवर उपस्थित राहावे, ही नम्र विनंती.
                  </p>
                </div>

                <div className="mt-8 flex flex-wrap gap-3">
                  {chips.map((c) => (
                    <div
                      key={c.k}
                      className="group rounded-2xl border border-gold-300/40 bg-[linear-gradient(140deg,rgba(125,20,37,0.7),rgba(37,5,12,0.7))] px-5 py-3 transition-all duration-500 hover:-translate-y-1 hover:border-gold-200/80"
                    >
                      <p className="font-latin text-[9px] tracking-[0.34em] text-gold-200/55 uppercase">
                        {c.k}
                      </p>
                      <p className="font-display text-base text-gold-100 transition-colors duration-500 group-hover:text-gold-50 sm:text-lg">
                        {c.v}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="mt-8">
                  <Divider tone="gold" width={360} className="opacity-70" />
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
