import { IMG } from "@/lib/assets";
import { Petals } from "@/components/ui";

/** Layered ambient parchment + gold ambience that sits behind the whole page. */
export function Backdrop() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <img
        src={IMG.parchment}
        alt=""
        className="absolute inset-0 h-full w-full object-cover opacity-80"
      />
      <div className="damask absolute inset-0 opacity-70" />

      {/* warm royal glows */}
      <div className="anim-halo absolute -top-48 -left-40 h-[38rem] w-[38rem] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.28),transparent_62%)] blur-2xl" />
      <div
        className="anim-halo absolute top-[28%] -right-52 h-[42rem] w-[42rem] rounded-full bg-[radial-gradient(circle,rgba(155,27,48,0.16),transparent_64%)] blur-2xl"
        style={{ animationDelay: "-3.4s" }}
      />
      <div
        className="anim-halo absolute bottom-[-14rem] left-[18%] h-[34rem] w-[34rem] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.2),transparent_66%)] blur-2xl"
        style={{ animationDelay: "-6s" }}
      />

      {/* slowly turning mandala watermarks */}
      <img
        src={IMG.mandala}
        alt=""
        className="anim-spin-slower absolute top-[14%] -right-32 w-[34rem] opacity-[0.08]"
      />
      <img
        src={IMG.mandala}
        alt=""
        className="anim-spin-slow absolute top-[58%] -left-36 w-[32rem] opacity-[0.07]"
      />
      <img
        src={IMG.mandala}
        alt=""
        className="anim-spin-slower absolute top-[88%] right-[6%] w-[22rem] opacity-[0.06]"
      />

      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(255,250,241,0.55),rgba(241,228,203,0.15)_30%,rgba(214,192,152,0.5))]" />
      {/* gentle page-wide petal drift */}
      <Petals count={9} minSize={7} maxSize={15} minDur={17} maxDur={30} className="opacity-60" />
    </div>
  );
}
